#ifndef SensorHTTPClient_H
#define SensorHTTPClient_H

#include <HTTPClient.h>
  
class SensorHTTPClient{
  
  public:
	SensorHTTPClient();
	~SensorHTTPClient(); 

	void SendAlert_IFTTT( char eventName[16], char val1[16], char val2[16] );
	
};

#endif