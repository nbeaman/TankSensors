#include "SensorHTTPClient.h" //include the declaration for this class 



//<<constructor>> setup the LED, make pin 13 an OUTPUT
SensorHTTPClient::SensorHTTPClient(){

}
 
//<<destructor>>
SensorHTTPClient::~SensorHTTPClient(){/*nothing to destruct*/}


void SensorHTTPClient::SendAlert_IFTTT( char eventName[16], char val1[16], char val2[16] ){
    HTTPClient http;
    
    http.begin("https://maker.ifttt.com/trigger/" + eventName + "/with/key/dOO4GGcvxO_pBa0QPwHN19");
    //http.addHeader("Content-Type", "text/plain");             //Specify content-type header
    http.addHeader("Content-Type", "application/json");

    String JSONtext = "{ \"value1\" : \"" + val1 + "\", \"value2\" : \"" + val2 + "\" }";
    Serial.println(JSONtext);

    int httpResponseCode = http.POST(JSONtext);   //Send the actual POST request
    // * could check for response - on my todo list * //
}