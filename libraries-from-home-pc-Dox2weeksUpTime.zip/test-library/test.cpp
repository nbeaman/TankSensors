#include "test.h" //include the declaration for this class


int i;
int iMax;
 
//<<constructor>>
test::test(){
	test::i=0;
	test::iMax=450;
}
 
//<<destructor>>
test::~test(){/*nothing to destruct*/}

char test::AddToIndex(char S[16], char T[16]){
	return S[3];
	
}