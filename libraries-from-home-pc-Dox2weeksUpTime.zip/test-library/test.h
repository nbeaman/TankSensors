#ifndef test_H
#define test_H


class test{

  public:
	test();
	~test();

	int i;
	int iMax;
	
	char AddToIndex(char S[16], char T[16]);
};

#endif