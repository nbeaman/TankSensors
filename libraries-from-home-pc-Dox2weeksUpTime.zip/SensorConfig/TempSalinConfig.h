#define config_WIFI_SSID "HOME-55A2"
#define config_WIFI_PASSWORD "3E7D73F4CED37FAC"
#define config_LED_NUMBER_OF_PINS 12
#define config_DOxSensorAddress          97
#define config_SalinitySensorAddress     100
#define config_TemperatureSensorAddress  102